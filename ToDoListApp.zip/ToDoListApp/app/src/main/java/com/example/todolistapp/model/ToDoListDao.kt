package com.example.todolistapp.model

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface ToDoListDao {

    @Query("SELECT * FROM ToDoListData ORDER BY timeCreated DESC")
    fun getAllToDoList() : LiveData<List<ToDoListData>>

    @Insert
    fun addToDoList(toDoListData : ToDoListData)

    @Query("Delete from ToDoListData where id = :id")
    fun deleteToDoList(id : Int)
}