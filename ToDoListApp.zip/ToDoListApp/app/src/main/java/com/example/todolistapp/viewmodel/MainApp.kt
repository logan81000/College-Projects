package com.example.todolistapp.viewmodel


import android.app.Application
import androidx.room.Room
import com.example.todolistapp.model.ToDoListDatabase;

class MainApp : Application() {

    companion object {
        lateinit var todolistDatabase : ToDoListDatabase
    }

    override fun onCreate() {
        super.onCreate()
        todolistDatabase= Room.databaseBuilder(
            applicationContext,
            ToDoListDatabase::class.java,
            ToDoListDatabase.NAME
        ).build()
    }

}
