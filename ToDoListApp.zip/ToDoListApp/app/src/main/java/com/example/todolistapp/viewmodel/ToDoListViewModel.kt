package com.example.todolistapp.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.todolistapp.model.ToDoListDao
import com.example.todolistapp.model.ToDoListData
import java.time.Instant
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Date

class ToDoListViewModel : ViewModel() {


    val toDoListDao = MainApp.todolistDatabase.getToDoListDao()

    val todoList : LiveData<List<ToDoListData>> = toDoListDao.getAllToDoList()


    fun addToDoList(title : String) {
        viewModelScope.launch(Dispatchers.IO) {
            toDoListDao.addToDoList(ToDoListData(title = title, timeCreated = Date.from(Instant.now())))
        }

    }

    fun deleteToDoList(id : Int) {
        viewModelScope.launch(Dispatchers.IO) {
            toDoListDao.deleteToDoList(id)
        }

    }
}
