package com.example.todolistapp.model

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.todolistapp.view.Converters

@Database(entities = [ToDoListData::class], version = 1)
@TypeConverters(Converters::class)
abstract class ToDoListDatabase : RoomDatabase() {
    companion object {
        const val NAME = "ToDo_DB"
    }

    abstract fun getToDoListDao() : ToDoListDao

}